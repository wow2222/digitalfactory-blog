The System Builder's Toolkit: 15 Templates for Building Business Processes That Run Without You
============================================================

WHAT'S IN THIS BUNDLE:

1. Guide_[title].pdf
   Complete guide with instructions and template descriptions.
   Read this first.

2. Templates_[title].xlsx
   For Excel and Google Sheets users.
   Open in Excel or upload to Google Drive > Open with Google Sheets.

3. Notion_*.csv files
   For Notion users. Import each CSV as a Notion database:
   Notion > New page > Database > Import > Upload CSV file.
   Each CSV becomes a fully structured database.

GETTING STARTED:
- Excel/Google Sheets: open the .xlsx file
- Notion: import each CSV file as a separate database
- Start with the Revenue Dashboard, then add the Content Calendar

Questions? Leave a review on Gumroad — we read every one.
